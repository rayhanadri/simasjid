            <!-- footer -->
            <footer class="footer"> © 2018 All rights reserved. Template designed by <a href="https://colorlib.com">Colorlib</a></footer>
            <!-- End footer -->
        </div>
        <!-- End Page wrapper  -->
    </div>
    <!-- End Wrapper -->

    <!-- All Jquery -->
   
    <script src="<?php echo base_url('assets/js/lib/jquery/jquery.min.js'); ?>"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="<?php echo base_url('assets/js/lib/bootstrap/js/popper.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/lib/bootstrap/js/bootstrap.min.js'); ?>"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="<?php echo base_url('assets/js/jquery.slimscroll.js'); ?>"></script>
    <!--Menu sidebar -->
    <script src="<?php echo base_url('assets/js/sidebarmenu.js'); ?>"></script>
    <!--stickey kit -->
    <script src="<?php echo base_url('assets/js/lib/sticky-kit-master/dist/sticky-kit.min.js'); ?>"></script>
    <!--Custom JavaScript -->
    <script src="<?php echo base_url('assets/js/custom.min.js'); ?>"></script>

    <!-- Amchart -->
     <script src="<?php echo base_url('assets/js/lib/morris-chart/raphael-min.js'); ?>"></script>
    <!-- <script src="<?php //echo base_url('assets/js/lib/morris-chart/morris.js'); ?>"></script> -->
    <!-- <script src="<?php //echo base_url('assets/js/lib/morris-chart/dashboard1-init.js'); ?>"></script> -->


	<script src="<?php echo base_url('assets/js/lib/calendar-2/moment.latest.min.js'); ?>"></script>
    <!-- scripit init-->
    <script src="<?php echo base_url('assets/js/lib/calendar-2/semantic.ui.min.js'); ?>"></script>
    <!-- scripit init-->
    <script src="<?php echo base_url('assets/js/lib/calendar-2/prism.min.js'); ?>"></script>
    <!-- scripit init-->
    <script src="<?php echo base_url('assets/js/lib/calendar-2/pignose.calendar.min.js'); ?>"></script>
    <!-- scripit init-->
    <script src="<?php echo base_url('assets/js/lib/calendar-2/pignose.init.js'); ?>"></script>

    <script src="<?php echo base_url('assets/js/lib/owl-carousel/owl.carousel.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/lib/owl-carousel/owl.carousel-init.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/scripts.js'); ?>"></script>
    <!-- scripit init-->

    <!-- datepicker -->
    <script src="<?php echo base_url('assets/js/lib/datepicker/tempusdominus-bootstrap-4.min.js'); ?>"></script>
    <script type="text/javascript">
            $(function () {
                $('#datetimepicker5').datetimepicker();
            });
        </script>
    <script src="<?php echo base_url('assets/js/lib/datepicker/bootstrap-datepicker.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/lib/datepicker/bootstrap-datepicker.min.js'); ?>"></script>
    <!-- <script src="<?php //echo base_url('assets/js/lib/datepicker/bootstrap-datepicker.js'); ?>"></script>
    <script src="<?php //echo base_url('assets/js/lib/datepicker/bootstrap-datepicker.min.js'); ?>"></script>
    <script type="text/javascript">
                  $('.datepicker').datepicker({
    format: 'mm/dd/yyyy',
    startDate: '-3d'
});
     </script> -->
    <!-- <script src="<?php //echo base_url('assets/js/lib/gmap/gmapApi.js');?>"></script>
    <script src="<?php //echo base_url('assets/js/lib/gmap/gmaps.js');?>"></script>
    <script src="<?php //echo base_url('assets/js/lib/gmap/gmap.init.js');?>"></script> -->

    <!-- Data tables -->
    <script src="<?php echo base_url('assets/js/lib/datatables/datatables.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/lib/datatables/cdn.datatables.net/buttons/1.2.2/js/dataTables.buttons.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/lib/datatables/cdn.datatables.net/buttons/1.2.2/js/buttons.flash.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/lib/datatables/cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/lib/datatables/cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/lib/datatables/cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/lib/datatables/cdn.datatables.net/buttons/1.2.2/js/buttons.html5.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/lib/datatables/cdn.datatables.net/buttons/1.2.2/js/buttons.print.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/lib/datatables/datatables-init.js'); ?>"></script>

    <script src="<?php echo base_url('assets/js/custom.min.js'); ?>"></script>

    <!-- Moment manipulate date -->
    <script src="<?php echo base_url('assets/js/lib/moment/moment.js'); ?>"></script>

</body>

</html>