<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Main Content -->
<div class="main-content">
  <section class="section">
    <div class="section-header">
      <h1>Blank Page</h1>
      <div></div>

    </div>

    <div class="section-body">
      <?php
      echo 'ini Home' . '<br>';
      echo $token;
      echo '<br>';
      echo '<br>';
      echo 'detail pengguna';
      echo '<br>';
      //data anggota dari array result
      echo $idAnggota = $result['data_anggota']['idAnggota'];
      echo $idJabatanAnggota = $result['data_anggota']['idJabatanAnggota'];
      echo $namaAnggota = $result['data_anggota']['namaAnggota'];
      echo $username = $result['data_anggota']['username'];
      ?>
      <br><br>
      <select class="form-control select2" style="width: 100%">
        <option>Option 1</option>
        <option>Option 2</option>
        <option>Option 3</option>
      </select>

      <div class="form-group">
        <label>Date Picker</label>
        <input type="text" class="form-control datepicker">
      </div>
      <div class="form-group">
        <label>Date Time Picker</label>
        <input type="text" class="form-control datetimepicker">
      </div>
      <div class="form-group">
        <label>Time Picker</label>
        <div class="input-group">
          <div class="input-group-prepend">
            <div class="input-group-text">
              <i class="fas fa-clock"></i>
            </div>
          </div>
          <input type="text" class="form-control timepicker">
        </div>
      </div>
    </div>
  </section>
</div>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\simasjid\sistemlaravel\simasjid\resources\views/homePage.blade.php ENDPATH**/ ?>