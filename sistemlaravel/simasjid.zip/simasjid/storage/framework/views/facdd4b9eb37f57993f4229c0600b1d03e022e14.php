<body>
  <div id="app">
    <section class="section">
      <div class="container mt-5">
        <div class="row">
          <div class="col-12 col-sm-10 offset-sm-1 col-md-8 offset-md-2 col-lg-8 offset-lg-2 col-xl-8 offset-xl-2">
            <div class="login-brand">
              <img src="<?php echo e(route('home')); ?>/public/dist/assets/img/ibnusina.jpg" alt="logo" width="100" class="shadow-light rounded-circle">
            </div>
            <div class="card card-primary">
              <div class="card-header">
                <h4>Register</h4>
              </div>
              <div class="card-body">
                <form method="POST" action="<?php echo e(route('register')); ?>">
                  <?php echo csrf_field(); ?>
                  <div class="form-group row">
                    <label for="username" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Akses Akun')); ?></label>
                    <div class="col-md-6">
                      <select class="form-control" id="id_jabatan" name="id_jabatan" required>
                        <option value=8>Takmir Masjid</option>
                        <option value=9>Remaja Masjid</option>
                      </select>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="username" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Username')); ?></label>
                    <div class="col-md-6">
                      <input id="username" type="text" class="form-control <?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="username" value="<?php echo e(old('username')); ?>" required autocomplete="username" autofocus placeholder="Username">
                      <?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?>
                      <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                      </span>
                      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>
                    <div class="col-md-6">
                      <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="new-password" placeholder="Password">
                      <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                      <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                      </span>
                      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Konfirmasi Password')); ?></label>
                    <div class="col-md-6">
                      <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password" placeholder="Konfirmasi Password">
                    </div>
                  </div>
                  <hr>
                  <h5 style="text-align:center"> Biodata </h5>
                  <div class="form-group row">
                    <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nama')); ?></label>
                    <div class="col-md-6">
                      <input id="name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="nama" value="<?php echo e(old('nama')); ?>" required autocomplete="nama" autofocus placeholder="Nama">
                      <?php if ($errors->has('nama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama'); ?>
                      <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                      </span>
                      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Email')); ?></label>
                    <div class="col-md-6">
                      <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" placeholder="Email">
                      <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                      <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                      </span>
                      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Alamat')); ?></label>

                    <div class="col-md-6">
                      <textarea id="alamat" type="text" class="form-control <?php if ($errors->has('alamat')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('alamat'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="alamat" value="<?php echo e(old('alamat')); ?>" autocomplete="alamat">
                      </textarea>
                      <?php if ($errors->has('alamat')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('alamat'); ?>
                      <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                      </span>
                      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                  </div>

                  <div class="form-group row">
                    <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('No Telp/HP')); ?></label>
                    <div class="col-md-6">
                      <input id="telp" type="text" class="form-control <?php if ($errors->has('telp')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('telp'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="telp" value="<?php echo e(old('telp')); ?>" autocomplete="telp" placeholder="Np. Telepon/HP">
                      <?php if ($errors->has('telp')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('telp'); ?>
                      <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                      </span>
                      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-lg-6 offset-lg-4" style="text-align:center;">
                      <button type="submit" class="btn btn-primary" style="width: 100%">
                        <?php echo e(__('Register')); ?>

                      </button>
                    </div>
                  </div>
                </form>
                <br><br>
                <div class="row">
                  <div class="col-lg-6">
                    <a class="btn btn-sm btn-outline-info" href="<?php echo e(route('login')); ?>" style="width:100%; margin-top: 5px;">
                      <?php echo e(__('Sudah punya akun? Login di sini.')); ?>

                    </a>
                  </div>
                  <div class="col-lg-6">
                    <a class="btn btn-sm btn-outline-success" href="<?php echo e(route('password.request')); ?>" style="width:100%; margin-top: 5px;">
                      <?php echo e(__('Lupa Password? Klik di sini.')); ?>

                    </a>
                  </div>
                </div>

              </div>
            </div>
            <div class="simple-footer">
              Copyright &copy; Stisla 2018
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\simasjid\sistemlaravel\simasjid\resources\views/auth/register.blade.php ENDPATH**/ ?>